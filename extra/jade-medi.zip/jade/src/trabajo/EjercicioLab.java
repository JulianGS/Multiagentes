package trabajo;

import jade.core.Agent;
import jade.core.behaviours.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.ResultSet; 
import java.sql.Statement; 
import javax.swing.JOptionPane; 
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import org.jsoup.Jsoup;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
 
public class EjercicioLab extends Agent{
 
    private Behaviour comp; 
 
    protected void setup()
    {
     comp = new MiComportamiento1();
     addBehaviour(comp);
    }
    protected void takeDown()
    {
        System.out.println("****Liberando Recursos****");
    } 
    //Definición de un comportamiento
    private class MiComportamiento1 extends Behaviour{ 
	
	private Document doc;
        private Elements links;
        private Elements media;
        private Elements imports;

	public void onStart(){
	   System.out.println("Mi nombre es: "+getName() );
	   String url = "http://amazon.com/";
           print("Fetching %s...", url);
	}
    	public void action(){
	   doc = Jsoup.connect(url).get();
           links = doc.select("a[href]");
           media = doc.select("[src]");
           imports = doc.select("link[href]");
/*

	Hasta aqui quedaria recopilada la informacion de la pagina, ahora habría que ver el objetivo del agente, para ver que información es almacenada el BD y que objetivo hay que satisfacer para que acabe.

*/
	   for (Element link : imports) {
              print(" * %s <%s> (%s)", link.tagName(),link.attr("abs:href"), link.attr("rel"));
           }

           print("\nLinks: (%d)", links.size());
        }
    	public boolean done(){
	    return true;
        }
        public int onEnd(){
            
            return 0;
        }

	private void print(String msg, Object... args) {
            System.out.println(String.format(msg, args));
        }
        private String trim(String s, int width) {
            if (s.length() > width)
                return s.substring(0, width-1) + ".";
            else
                return s;
        }
    }//Fin clase behaviour

    private class Conexion { 
/*
	La implementación de los metodos de esta clase no esta empezada, para ello es necesario usar antes windows 10
*/
	   Connection conexion; 
	   Statement sentencia;
	   private final String CLAVE_BASE_DE_DATOS = "";
	   private final String USUARIO_BASE_DE_DATOS = "admin";
	   private final String NOMBRE_BASE_DE_DATOS = "C:\\Users\\9alej\\Documents\\NetBeansProjects\\TrabajoFinGrado\\database.accdb";
	   


	   public Conexion(){ }
	 
	   public void PrepararBaseDatos() { 
		try{ 
		    conexion=DriverManager.getConnection("jdbc:ucanaccess://"+this.NOMBRE_BASE_DE_DATOS,this.USUARIO_BASE_DE_DATOS,this.CLAVE_BASE_DE_DATOS);
		    
		} 
		catch (Exception e) { 
		    JOptionPane.showMessageDialog(null,"Error al realizar la conexion "+e);
		} 
		try { 
		    sentencia=conexion.createStatement( 
		            ResultSet.TYPE_SCROLL_INSENSITIVE, 
		            ResultSet.CONCUR_READ_ONLY); 
		    
		    System.out.println("Se ha establecido la conexión correctamente");
		} 
		catch (Exception e) { 
		    JOptionPane.showMessageDialog(null,"Error al crear el objeto sentencia "+e);
		} 
	   }
	 
	   public void desconectar(){
		try {
		    conexion.close();            
		    System.out.println("La conexion a la base de datos a terminado");
		} catch (SQLException ex) {
		    System.out.println( ex.getMessage() );
		}       
	   }
	 
	   public ArrayList<String> cargarDatos(){
		   ArrayList<String> datos = new ArrayList<String>();
		    
		   String sql = " SELECT * FROM Validos ; ";

		   try {
			PreparedStatement pstm = conexion.prepareStatement(sql);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
			    datos.add(res.getString("serie"));      
			}
			res.close();
		    } catch (SQLException e) {
			System.err.println(e.getMessage());
		    }

		    return datos;
	    }

    }//Clase Conexion
}
