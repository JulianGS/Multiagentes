package examples;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.core.NotFoundException;

public class AgenteH extends Agent{
	private int a;
	private Behaviour inc, dec, control;
	private ThreadedBehaviourFactory tbf;
	protected void setup(){
		a = (int) (Math.random()*100);
		System.out.println("Valor A-->"+a);
		tbf = new ThreadedBehaviourFactory();
		inc = new Comportamiento(0);
		dec = new Comportamiento(1);
		control = new Control();
		addBehaviour(tbf.wrap(inc));
		addBehaviour(tbf.wrap(dec));
		addBehaviour(tbf.wrap(control));
	}
	protected void takeDown(){
		try{
			tbf.interrupt(inc);
			tbf.interrupt(dec);
		}catch(NotFoundException nfe){
			System.out.println("ERROR-->"+nfe.getMessage());
		}
		super.takeDown();
		System.out.println(getLocalName()+": Ejecucion Finalizada");
	}
	private class Comportamiento extends Behaviour{
		private int opcion;
		public Comportamiento(int opcion){
			this.opcion =opcion;
		}
		public void action(){
			String nombre ="";
			if(opcion == 1){
				a--;
				nombre = "DECREMENTO";
			}
			else{
				a++;
				nombre = "INCREMENTO";
			}
			System.out.println(nombre+":<---Valor A-->"+a);
		}
		public boolean done(){
			return false;
		}
	}
	private class Control extends Behaviour{
		private boolean fin;
		public void onStart(){
			fin=false;
		}
		public void action(){
			if(a==50){
				fin=true;
			}
		}
		public boolean done(){
			return fin;
		}
	}
}
