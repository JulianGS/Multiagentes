package examenhebras;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.core.NotFoundException;

public class ejercicio1 extends Agent{
	private ThreadedBehaviourFactory tbf;
	private Behaviour comp1, comp2, timeOut;
	private int a;
	/*	Ejercicio a)
	protected void setup(){
		a = 0;
		ParallelBehaviour pb = new ParallelBehaviour(this, ParallelBehaviour.WHEN_ANY){
			public int onEnd(){
				myAgent.doDelete();
				return 0;
			}
		};
		comp1 = new Comp(1,2000);
		comp2 = new Comp(2,3000);
		timeOut = new TimeOut(this,12000);
		pb.addSubBehaviour(comp1);
		pb.addSubBehaviour(comp2);
		pb.addSubBehaviour(timeOut);
		addBehaviour(pb);
	}*/
	// 	Ejercicio b)
	protected void setup(){
		a = 0;
		ParallelBehaviour pb = new ParallelBehaviour(this, ParallelBehaviour.WHEN_ANY){
			public int onEnd(){
				try{
					Thread td = tbf.getThread(comp2);
					td.interrupt();
				}catch(Exception e){
					System.out.println("Amai, donde esta la hebra");
				}
				myAgent.doDelete();
				return 0;
			}
		};
		comp1 = new Comp(1,2000);
		comp2 = new Comp(2,3000);
		timeOut = new TimeOut(this,12000);
		pb.addSubBehaviour(comp1);
		pb.addSubBehaviour(timeOut);
		tbf = new ThreadedBehaviourFactory();
		addBehaviour(tbf.wrap(comp2));
	
		addBehaviour(pb);
	}
	protected void takeDown(){
		
		System.out.println("Liberando recursos...");
	}
	private class Comp extends Behaviour{
		private int id;
		private int n;
		private boolean fin;

		public Comp(int id, int n){
			this.n = n;
			this.id = id;
			this.fin = false;
		}
		public void action(){
			a++;
			try{
				Thread.sleep(this.n);
			}catch(InterruptedException e){
				fin = true;
			}
			System.out.println("Comp" + this.id + " : valor " + a);
		}
		public boolean done(){
			return fin;
		}
	}
	private class TimeOut extends WakerBehaviour{
		public TimeOut(Agent a, long time){
			super(a,time);
		}
		public void onWake(){
			System.out.println("Soy el comportamiento TimeOut y voy a matar al agente");
		}
		public int onEnd(){		
			
			return 0;
		}
	}
}
