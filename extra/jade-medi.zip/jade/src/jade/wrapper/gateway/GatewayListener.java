package jade.wrapper.gateway;

public interface GatewayListener {
	void handleGatewayConnected();
	void handleGatewayDisconnected();
}
