package inventados;

import jade.core.Agent;
import jade.core.behaviours.*;

public class ejercicioLab3 extends Agent{
	ParallelBehaviour pb;

	protected void setup(){
		pb = new ParallelBehaviour(this,ParallelBehaviour.WHEN_ALL){
			public int onEnd(){
				reset();
				myAgent.doDelete();
				return super.onEnd();
			}
		};
		pb.addSubBehaviour(new Comp1());
		pb.addSubBehaviour(new Comp2());
		pb.addSubBehaviour(new Comp3(this,5000));
		
		addBehaviour(pb);
	}

	private class Comp1 extends Behaviour{
		private int c;
		public void onStart(){
			c = 0;
		}
		public void action(){
			System.out.println("Soy el comportamiento1 y estoy en la ejecucion " + c++);
		}
		public boolean done(){
			return c > 3;
		}
	}
	private class Comp2 extends OneShotBehaviour{
		public void action(){
			System.out.println("Soy el comportamiento2");
		}
	}
	private class Comp3 extends WakerBehaviour{
		public Comp3(Agent a, long b){
			super(a,b);
		}
		public void onWake(){
			System.out.println("Soy el comportamiento3 y acabo de despertar");
		}
	}
}
