package inventados;

import jade.core.Agent;
import jade.core.behaviours.*;

public class ejercicioLab2 extends Agent{
	private FSMBehaviour fsmb;
	
	protected void setup(){
		fsmb = new FSMBehaviour(this){
			public int onEnd(){
				reset();
				myAgent.doDelete();
				return super.onEnd();
			}
		};

		String INICIO = "INICIO", ESTADO1 = "ESTADO1", ESTADO2 = "ESTADO2", FIN="FIN";
		fsmb.registerFirstState(new Estado(INICIO),INICIO);
		fsmb.registerState(new Estado(ESTADO1),ESTADO1);
		fsmb.registerState(new Estado2(),ESTADO2);
		fsmb.registerLastState(new Estado(FIN),FIN);
		
		fsmb.registerDefaultTransition(INICIO, ESTADO1);
		fsmb.registerDefaultTransition(ESTADO1, ESTADO1);
		fsmb.registerTransition(ESTADO1,ESTADO2,3);
		fsmb.registerDefaultTransition(ESTADO2, FIN);

		addBehaviour(fsmb);
	}
	protected void takeDown(){
		System.out.println("Liberando Recursos");
	}
	private class Estado extends OneShotBehaviour{
		private String name;
		public Estado(String name){
			this.name = name;		
		}	
		public void action(){
			System.out.println("Soy el estado " + this.name);
		}
		public int onEnd(){
			if(this.name.equals("ESTADO1")){
				if(((int)(Math.random()*4))>2)
					return 3;
				else
					return 0;
			}
			else{
				return 0;
			}
		}
	}
	private class Estado2 extends Behaviour{
		public void action(){
			System.out.println("Soy el estado ESTADO2");
		}
		public boolean done(){
			return true;
		}
		public int onEnd(){
			return 0;
		}
	}
}
