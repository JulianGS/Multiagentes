package inventados;

import jade.core.Agent;
import jade.core.behaviours.*;

public class ejercicio0 extends Agent{
	SequentialBehaviour sq;
	FSMBehaviour fsmb;
	ParallelBehaviour p;

	protected void setup(){
		sq = new SequentialBehaviour(this){
			public int onEnd(){
				reset();
				myAgent.doDelete();
				return super.onEnd();
			}		
		};
		fsmb = declararFSMB();
		sq.addSubBehaviour(fsmb);
		
		addBehaviour(sq);

	}
	protected void takeDown(){
		System.out.println("Liberando Recursos");
	}
	private class Estado extends OneShotBehaviour{
	
		private String name;
		private int n;

		public Estado(String name, int n){
			this.name = name;
			this.n = n;
		}
		public void action(){
			System.out.println("Soy el comportamiento " + this.name);
		}
		public int onEnd(){
			if(this.name.equals("3")){
				if(n != 5){
					System.out.println("Añadiendo fsmb...");
					sq.addSubBehaviour(declararFSMB());
				}else{
					System.out.println("Ha salido : " + this.n + " FIN");
				}
			}
			return ((int)(Math.random()*3));
		}
	}
	private FSMBehaviour declararFSMB(){
		String A="1", B="2", C="3";
		
		FSMBehaviour f = new FSMBehaviour();

		f.registerFirstState(new Estado(A,((int)(Math.random()*10))), A);
		f.registerState(new Estado(B,((int)(Math.random()*10))), B);
		f.registerLastState(new Estado(C,((int)(Math.random()*10))), C);

		f.registerTransition(A,B,2);
		f.registerDefaultTransition(A,A);
		f.registerTransition(B,A,0);
		f.registerTransition(B,B,1);
		f.registerTransition(B,C,2);
		
		return f;
	}
	
}
