package examencomunicacion;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.core.AID;

public class alex1Receptor extends Agent{
	protected void setup(){
		System.out.println("RECEPTOR: Acaba de activarse");
		addBehaviour(new Receptor());
	}
	protected void takeDown(){
		super.takeDown();
		System.out.println("RECEPTOR: Liberando recursos...");
	}
	private class Receptor extends CyclicBehaviour{
		private MessageTemplate plantilla;
		public Receptor(){
			plantilla = null;
			AID id = new AID();
			id.setLocalName("e");
			MessageTemplate user = MessageTemplate.MatchSender(id);
			MessageTemplate perf = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
			MessageTemplate languaje = MessageTemplate.MatchLanguage("small");
			//plantilla = MessageTemplate.and(user, perf);
			//plantilla = MessageTemplate.and(plantilla, languaje);
			plantilla = languaje;
		}	
		public void action(){
			ACLMessage mensaje = blockingReceive(plantilla);
			System.out.println("RECEPTOR: Mensaje recibido: " + mensaje.getContent());
		}
	}
}
