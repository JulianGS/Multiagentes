package examencomunicacion;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import jade.core.AID;

public class alex3Emisor extends Agent{
	
	protected void setup(){
		System.out.println("EMISOR: Activado!");
		addBehaviour(new Emisor());
	}
	protected void takeDown(){
		System.out.println("EMISOR: Liberando recursos ...");
		super.takeDown();
	}
	private class Emisor extends Behaviour{
		private boolean fin;
		public Emisor(){
			fin = false;
		}
		public void action(){
			ACLMessage muere = receive();
			if(muere == null){
				ACLMessage mensaje = new ACLMessage(ACLMessage.REQUEST);
				AID id = new AID();
				id.setLocalName("r");
				mensaje.addReceiver(id);
				int n = ((int)(Math.random()*1000));
				if(n > 200) mensaje.setLanguage("Big");
				else mensaje.setLanguage("Small");
				mensaje.setContent(""+n);
				send(mensaje);
			}else
				fin = true;
		}
		public boolean done(){
			return fin;
		}
		public int onEnd(){
			myAgent.doDelete();
			return super.onEnd();
		}
	}
}
