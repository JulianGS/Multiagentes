package examencomunicacion;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import jade.core.AID;

public class alex2Receptor extends Agent{
	private int timeout;
	private SequentialBehaviour sq;

	protected void setup(){
		System.out.println("RECEPTOR: Activado");
		timeout = 0;
		sq = new SequentialBehaviour(this){
			public int onEnd(){
				myAgent.doDelete();
				return super.onEnd();
			}
		};
		sq.addSubBehaviour(new Receptor());

		addBehaviour(sq);
	}
	protected void takeDown(){
		super.takeDown();
		System.out.println("RECEPTOR: Liberando Recursos");
	}
	private class Receptor extends Behaviour{
		private MessageTemplate plantilla;
		public void onStart(){
			plantilla = null;
			AID emisor = new AID();
			emisor.setLocalName("e");
			MessageTemplate filtrouser = MessageTemplate.MatchSender(emisor);
			MessageTemplate filtrotipo = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
			MessageTemplate filtroidioma = MessageTemplate.MatchLanguage("Spanish");
			plantilla = MessageTemplate.and(filtrouser, filtrotipo);
			plantilla = MessageTemplate.and(plantilla, filtroidioma);
		}
		public void action(){
			ACLMessage mensaje = blockingReceive(plantilla);
			System.out.println("RECEPTOR: Mensaje recibido: " + mensaje.getContent());
			timeout++;
		}	
		public boolean done(){
			return timeout > 10;
		}
		public int onEnd(){
			sq.addSubBehaviour(new Matar());
			return 0;
		}
	}
	public class Matar extends OneShotBehaviour{
		public void action(){
			System.out.println("RECEPTOR: Preparando Mensaje Para Matar a Emisor");
			ACLMessage mensaje = new ACLMessage(ACLMessage.REQUEST);
			AID id = new AID();
			id.setLocalName("e");
			mensaje.addReceiver(id);
			mensaje.setLanguage("Spanish");
			mensaje.setContent("Muere");

			send(mensaje);
		}
	}
}
