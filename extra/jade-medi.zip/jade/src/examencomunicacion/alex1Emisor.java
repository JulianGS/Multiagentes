/*

	Se pretende implementar una comunicacion entre un emisor y un receptor, en la que el emisor le envia un numero entre 0 y 1000 (sin incluir) al 
	receptor, y este imprimirá el numero una vez que le llegue.
	Saber si es grande o pequeño el numero, se debe hacer en la parte del emisor, el receptor no puede leer el numero en ningun momento ni recibir ningun
	mensaje si es mayor a 600.

*/
package examencomunicacion;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import jade.core.AID;

public class alex1Emisor extends Agent{
	protected void setup(){
		System.out.println("EMISOR: Acaba de activarse");
		addBehaviour(new Emisor());
	}
	protected void takeDown(){
		super.takeDown();
		System.out.println("EMISOR: Liberando recursos...");
	}
	private class Emisor extends OneShotBehaviour{
		private AID receptor;
		public void onStart(){
			receptor = new AID();
			receptor.setLocalName("r");
		}
		public void action(){
			ACLMessage mensaje = new ACLMessage(ACLMessage.REQUEST);
			//mensaje.setPerformative(ACLMessage.REQUEST);
			int n = ((int)(Math.random()*1000));
			mensaje.setSender(getAID());
			System.out.println("EMISOR: Preparado mensaje: " + n);
			if(n > 600)
				mensaje.setLanguage("big");
			else
				mensaje.setLanguage("small");
			mensaje.setContent("" + n);
			mensaje.addReceiver(receptor);
			send(mensaje);
			block(500);
		}
		public int onEnd(){
			myAgent.doDelete();
			return 0;
		}
	}
}
