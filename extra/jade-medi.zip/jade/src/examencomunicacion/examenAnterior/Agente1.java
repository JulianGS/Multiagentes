package comunicacion;


import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import java.io.*;
import jade.lang.acl.MessageTemplate;

public class Agente1 extends Agent{
	protected void setup(){
		addBehaviour(new generador());
	}

	class generador extends Behaviour{
		int aleatorio;
		public void action(){
			aleatorio = (int)(Math.random() * 100000)+1;
			ACLMessage aclmsg = new ACLMessage(ACLMessage.REQUEST);
			aclmsg.addReceiver(new AID("Agente2",AID.ISLOCALNAME));
			aclmsg.setContent(String.valueOf(aleatorio));
			send(aclmsg);
			System.out.println("[Agente1] envia "+aleatorio+" al [Agente2]");
			

			MessageTemplate filtroEmisor = MessageTemplate.MatchSender(new AID("Agente2",AID.ISLOCALNAME));
			ACLMessage msg = blockingReceive(filtroEmisor);
			
			aleatorio = (Integer.parseInt(msg.getContent()));
			System.out.println("[Agente1] recibe "+aleatorio+" del [Agente2]");
			aclmsg = new ACLMessage(ACLMessage.REQUEST);
			aclmsg.addReceiver(new AID("Agente2",AID.ISLOCALNAME));

			aclmsg.setContent(String.valueOf(aleatorio));
			send(aclmsg);
			System.out.println("[Agente1] envia "+aleatorio+" al [Agente2]");
			
		}
		public boolean done(){
			return (aleatorio==0);
		}
		public int onEnd(){
			doDelete();
			return 0;
		}
	}
}