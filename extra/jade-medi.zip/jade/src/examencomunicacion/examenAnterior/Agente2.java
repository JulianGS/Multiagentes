package comunicacion;

import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;

public class Agente2 extends Agent{
	protected void setup(){
		addBehaviour(new generador());
	}

	class generador extends Behaviour{
		int aleatorio;
		public void action(){
			MessageTemplate filtroEmisor = MessageTemplate.MatchSender(new AID("Agente1",AID.ISLOCALNAME));
			ACLMessage msg = blockingReceive(filtroEmisor);
			aleatorio = (Integer.parseInt(msg.getContent())/2);
			System.out.println("[Agente2] recibe "+(aleatorio*2)+" del [Agente1]");
			ACLMessage aclmsg = new ACLMessage(ACLMessage.REQUEST);
			aclmsg.addReceiver(new AID("Agente3",AID.ISLOCALNAME));

			aclmsg.setContent(String.valueOf(aleatorio));
			send(aclmsg);
			System.out.println("[Agente2] envia "+aleatorio+" al [Agente3]");

			filtroEmisor = MessageTemplate.MatchSender(new AID("Agente3",AID.ISLOCALNAME));

			msg = blockingReceive(filtroEmisor);

			aleatorio = (Integer.parseInt(msg.getContent()));
			System.out.println("[Agente2] recibe "+aleatorio+" del [Agente3]");
			aclmsg = new ACLMessage(ACLMessage.REQUEST);
			aclmsg.addReceiver(new AID("Agente1",AID.ISLOCALNAME));

			aclmsg.setContent(String.valueOf(aleatorio));
			send(aclmsg);
			System.out.println("[Agente2] envia "+aleatorio+" al [Agente1]");
			

		}
		public boolean done(){
			return (aleatorio==0);
		}
		public int onEnd(){
			doDelete();
			return 0;
		}
	}
}