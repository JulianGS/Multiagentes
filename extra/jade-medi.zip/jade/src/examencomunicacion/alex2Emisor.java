package examencomunicacion;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import jade.core.AID;

public class alex2Emisor extends Agent{
	protected void setup(){
		System.out.println("EMISOR: Activado");
		addBehaviour(new Emisor());
	}
	protected void takeDown(){
		super.takeDown();
		System.out.println("EMISOR: Liberando Recursos");
	}
	private class Emisor extends CyclicBehaviour{
		public void action(){
			ACLMessage muere = receive();
			if(muere != null){
				System.out.println("EMISOR: Mensaje recibido, voy a matarme xddd");
				myAgent.doDelete();
			}
			else{
				System.out.println("EMISOR: Preparando Mensaje");
				ACLMessage mensaje = new ACLMessage(ACLMessage.REQUEST);
				AID id = new AID();
				id.setLocalName("r");
				mensaje.addReceiver(id);
				mensaje.setLanguage("Spanish");
				mensaje.setContent("Hola receptor");

				send(mensaje);
				block(1000);
			}
		}
	}
}
