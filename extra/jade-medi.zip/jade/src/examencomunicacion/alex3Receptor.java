package examencomunicacion;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import jade.core.AID;

public class alex3Receptor extends Agent {
	private ThreadedBehaviourFactory tbf;
	protected void setup(){
		tbf = new ThreadedBehaviourFactory();
		ParallelBehaviour pb = new ParallelBehaviour(ParallelBehaviour.WHEN_ANY){
			public int onEnd(){
				ACLMessage mensaje = new ACLMessage(ACLMessage.REQUEST);
				AID id = new AID();
				id.setLocalName("e");
				mensaje.addReceiver(id);
				mensaje.setContent("Muere hijo de puta");
				send(mensaje);

				myAgent.doDelete();
				return super.onEnd();
			}		
		};
		System.out.println("RECEPTOR: Activado!");
		pb.addSubBehaviour(tbf.wrap(new Receptor()));
		pb.addSubBehaviour(tbf.wrap(new Receptor2()));
		addBehaviour(pb);
	}
	protected void takeDown(){
		System.out.println("RECEPTOR: Liberando recursos ...");
		tbf.interrupt();
		super.takeDown();
	}
	private class Receptor extends Behaviour{
		private MessageTemplate plantilla;
		private int index;
		public void onStart(){
			index = 0;
			plantilla = null;
			AID emisor = new AID();
			emisor.setLocalName("e");
			MessageTemplate tipo = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
			MessageTemplate sender = MessageTemplate.MatchSender(emisor);
			MessageTemplate idioma = MessageTemplate.MatchLanguage("Big");
			plantilla = MessageTemplate.and(tipo, sender);
			plantilla = MessageTemplate.and(plantilla, idioma);
		}
		public void action(){
			ACLMessage mensaje = blockingReceive(plantilla);
			System.out.println("<"+ (index++) + "> RECEPTOR1: Se ha recibido el mensaje : " + mensaje.getContent());
		}
		public boolean done(){
			return index > 5;
		}
	}

	private class Receptor2 extends Behaviour{
		private MessageTemplate plantilla;
		private int index;
		public void onStart(){
			index = 0;
			plantilla = null;
			AID emisor = new AID();
			emisor.setLocalName("e");
			MessageTemplate tipo = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
			MessageTemplate sender = MessageTemplate.MatchSender(emisor);
			MessageTemplate idioma = MessageTemplate.MatchLanguage("Small");
			plantilla = MessageTemplate.and(tipo, sender);
			plantilla = MessageTemplate.and(plantilla, idioma);
		}
		public void action(){
			ACLMessage mensaje = blockingReceive(plantilla);
			System.out.println("<"+ (index++) + "> RECEPTOR2: Se ha recibido el mensaje : " + mensaje.getContent());
		}
		public boolean done(){
			return index > 5;
		}
	}
}
