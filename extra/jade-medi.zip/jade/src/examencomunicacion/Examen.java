package examencomunicacion;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import jade.core.AID;

public class Examen extends Agent{
	private int id;
	protected void setup(){
		Object[] args = getArguments();
		if(args != null && args.length == 1){
			id = Integer.parseInt(args[0].toString());
			System.out.println("AGENTE<" + id + ">: Activado!");
			addBehaviour(new Comp(id));
		}
	}
	protected void takeDown(){
		System.out.println("AGENTE<" + id + ">: Liberando recursos ...");
		super.takeDown();
	}
	private class Comp extends CyclicBehaviour{
		private boolean iniciador, direccion_positiva;
		private int id;
		private String name_envio, name_recibo;
		private int n_actual;

		private MessageTemplate plantilla, plantilla2;

		public Comp(int id){
			this.plantilla = null;
			this.id = id;
			if(this.id == 1 | this.id == 3){
				this.name_envio = "ag2";
				this.name_recibo = "ag2";
			}
			if(this.id == 1){
				this.iniciador = true;
			}else if(this.id == 2){
				this.iniciador = false;
				this.direccion_positiva = true;
			}else if(this.id == 3){
				this.iniciador = false;
			}
		}		
		public void onStart(){
			AID aid_recibo = new AID();
			if(this.id == 1 || this.id == 3){
				aid_recibo.setLocalName(this.name_recibo);
				plantilla = MessageTemplate.MatchSender(aid_recibo);
			}else if(this.id == 2){
				aid_recibo.setLocalName("ag1");
				plantilla = MessageTemplate.MatchSender(aid_recibo);
				aid_recibo.setLocalName("ag3");
				plantilla2 = MessageTemplate.MatchSender(aid_recibo);
			}
		}
		public void action(){
			if(iniciador){
				ACLMessage primero = new ACLMessage(ACLMessage.REQUEST);
				AID uno_id = new AID();
				uno_id.setLocalName(this.name_envio);
				primero.addReceiver(uno_id);
				int rand = ((int)(Math.random()*1000));
				primero.setContent(""+rand);
	
				send(primero);
				
			}else{
				ACLMessage mensaje;
				if(this.id != 2)
					mensaje = blockingReceive(plantilla);
				else{
					if(this.direccion_positiva){
						mensaje = blockingReceive(plantilla);
					}else{
						mensaje = blockingReceive(plantilla2);
					}
				}
				String n = mensaje.getContent();
				this.n_actual = Integer.parseInt(n);
				ACLMessage envia = new ACLMessage(ACLMessage.REQUEST);
				AID aid_envia = new AID();
				if(this.id != 2){
					aid_envia.setLocalName(this.name_envio);
				}else{
					String last = mensaje.getSender().getLocalName();
					if(last.equals("ag1")){
						aid_envia.setLocalName("ag3");
						this.direccion_positiva = false;
					}else{
						aid_envia.setLocalName("ag1");
						this.direccion_positiva = true;
					}
				}
				System.out.println("AGENTE" + this.id + " NUMERO" + this.n_actual);
				envia.setSender(aid_envia);
				envia.setContent("" + (this.n_actual/2));

				send(envia);
			}
		}
	}
}
