package examples;

import jade.core.Agent;
import jade.core.behaviours.*;

 
public class ejerciciot3 extends Agent{
 
    private Behaviour comp, comp2; 
    private long startTime;
 
    protected void setup()
    {
     startTime = System.nanoTime();
     comp = new MiComportamiento1(2000);
     comp2 = new MiComportamiento1(3000);
     addBehaviour(comp);
     addBehaviour(comp2);
    }
    protected void takeDown()
    {
        System.out.println("Taking down");
	/*Thread td1 = tbf.getThread(comp);
	td1.interrupt();
	Thread td2 = tbf.getThread(comp2);
	td2.interrupt();
	super.takeDown();*/
    } 
    //Definición de un comportamiento
    private class MiComportamiento1 extends CyclicBehaviour{ 
	private long endTime;
	private int x;
	private int n;
	private long parada = (long) 12000000000;
	public MiComportamiento1(int n){
		this.n = n;
	}
    	public void action(){
	   endTime = System.nanoTime();
	   if((endTime - startTime) > parada){
		interrupt(comp);
		interrupt(comp2);
	   } 
	   Thread.sleep(this.n);
    	   System.out.println(getName() + "-> : El valor de x es: " + x);
	   this.x++;
        }
    }
}

