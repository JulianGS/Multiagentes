package examples;

import jade.core.Agent;
import jade.core.behaviours.*;

public class Ejercicio18Octubre extends Agent{
	private static final String STATE_O = "2.1";
	private static final String STATE_F = "2.2";
	private ParallelBehaviour sub1;

	protected void setup(){

		SequentialBehaviour seqBehaviour = new SequentialBehaviour(this) {
		      public int onEnd() {
			System.out.println("Sequential behaviour completed.");
			reset();
			return super.onEnd();
		      } 
		    };

		sub1 = new ParallelBehaviour(this, 1);
		sub1.addSubBehaviour(new Subcomportamiento1("1.1", (int)(Math.random()*100)));
		sub1.addSubBehaviour(new Subcomportamiento1("1.2", (int)(Math.random()*100)));
		sub1.addSubBehaviour(new Subcomportamiento1("1.3", (int)(Math.random()*100)));
	
		FSMBehaviour sub2 = new FSMBehaviour(this) {
			public int onEnd() {
				System.out.println("FSM behaviour completed.");
				myAgent.doDelete();
				return super.onEnd();
			}
		};
		sub2.registerFirstState(new Subcomportamiento2(), STATE_O);
		sub2.registerLastState(new NamePrinter(), STATE_F);

		sub2.registerDefaultTransition(STATE_O, STATE_O);
		sub2.registerTransition(STATE_O, STATE_F, 0);

		seqBehaviour.addSubBehaviour(sub1);
		seqBehaviour.addSubBehaviour(sub2);

		addBehaviour(seqBehaviour);

		
	}
	protected void takeDown(){
		System.out.println("Liberando recursos");
	}
	private class Subcomportamiento1 extends Behaviour{

		private String name;
		private int n_veces;

		public Subcomportamiento1(String name, int n_veces){
			this.name = name;
			this.n_veces = n_veces;
		}
		public void action(){
			System.out.println("Me llamo " + this.name + ". Restantes: " + this.n_veces);
			this.n_veces--;
		}
		public boolean done(){
			return (this.n_veces == 0) ;
		}
		public int onEnd(){
			System.out.println("El subcomportamiento " + this.name + " ha finalizado su ejecucion");
			removeBehaviour(sub1);
			return 0;
		}
	}
	private class Subcomportamiento2 extends OneShotBehaviour{
		
		private int n;
		private int resto;

		public void action(){
			System.out.println("Estado inicial, calculando numero ...");
			this.n = (int)(Math.random()*1000);
			System.out.println("Numero calculado: " + this.n);
			resto = n%2;
		}/*
		public boolean done(){
			return (resto == 0);
		}*/
		public int onEnd(){
			System.out.println("Estado final, numero calculado!");
			return resto;
		}
	}
	private class NamePrinter extends OneShotBehaviour{

		public void action(){
			System.out.println("He llegado al estado final");
		}
	}
}
