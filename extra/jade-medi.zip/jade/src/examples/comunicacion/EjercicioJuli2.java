package examples.comunicacion;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;
import jade.lang.acl.*;

/*
Utilizando el ejercicio "EjercicioExamen2" implementa un FSMB con 4 estados:

Primero: Se ejecuta 1 vez e imprime 1."FSMB"
Segundo: Se ejecuta 20 veces e imprime la iteración; AL ACABAR pone "2.FSMB".
Tercero: Envía un mensaje al receptor en el que pone "BIBA PROLOJ" con una AID "receptor". AL ACABAR pone "3. FSMB"
Cuarto: Imprime "4. FSMB" y en otra línea "FIN SFMB".

Este FSMB que hemos definido se ejecuta en paralelo con otro comportamiento compuesto. Definido a continuación:

Comportamiento paralelo que ejecute 2 comportamientos:

Primero: Cada 5s imprime "Me corro vivo"
Segundo: Espera la recepción del mensaje del comportamiento 3. Cuando lo reciba muestra el contenido del mensaje y
el lenguaje en el que está escrito

*/

public class EjercicioJuli2 extends Agent{
	protected void setup(){
		ParallelBehaviour pb = new ParallelBehaviour(this, 2){
			public int onEnd(){
				reset();
				return super.onEnd();
			}
		};
		pb.addSubBehaviour(new Bufador());
		pb.addSubBehaviour(new Receptor());
		addBehaviour(pb);
	}
	protected void takeDown(){
		System.out.println("Liberando recursos");
	}
	private class Bufador extends CyclicBehaviour{
		public void action(){
			block(5000);
			System.out.println("Me corro vivo!!");
		}	
	}
	private class Receptor extends OneShotBehaviour{
		private String receptorname;
		public void onStart(){
			receptorname = "emisor";
		}
		public void action(){
			System.out.println("RECEPTOR: Preparandose para recibir");
			ACLMessage mensaje = blockingReceive();
			if(mensaje != null){
				System.out.println("RECEPTOR: " + getLocalName() + ": recibe: " + mensaje.toString());
			}
		}
	}
}

