package examples.comunicacion;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.core.AID;
import jade.lang.acl.*;

/*
Utilizando el ejercicio "EjercicioExamen2" implementa un FSMB con 4 estados:

Primero: Se ejecuta 1 vez e imprime 1."FSMB"
Segundo: Se ejecuta 20 veces e imprime la iteración; AL ACABAR pone "2.FSMB".
Tercero: Envía un mensaje al receptor en el que pone "BIBA PROLOJ" con una AID "receptor". AL ACABAR pone "3. FSMB"
Cuarto: Imprime "4. FSMB" y en otra línea "FIN SFMB".

Este FSMB que hemos definido se ejecuta en paralelo con otro comportamiento compuesto. Definido a continuación:

Comportamiento paralelo que ejecute 2 comportamientos:

Primero: Cada 5s imprime "Me corro vivo"
Segundo: Espera la recepción del mensaje del comportamiento 3. Cuando lo reciba muestra el contenido del mensaje y
el lenguaje en el que está escrito

*/

public class EjercicioJuli extends Agent{

	SequentialBehaviour fsmb;

	protected void setup(){
		fsmb = new SequentialBehaviour(this){
			public int onEnd(){
				reset();
				return super.onEnd();
			}
		};
		fsmb.addSubBehaviour(new Estado(this, 1));
		addBehaviour(fsmb);
		
	}

	private class Estado extends OneShotBehaviour{
		private Agent a;
		private int id;

		public Estado(Agent a, int id){
			super(a);
			this.id = id;
			this.a = a;		
		}
		public void action(){
			System.out.println( id + ".FSMB");	
			if(id == 4)
				System.out.println("Fin");	
		}
		public int onEnd(){
			if(this.id == 1)
				fsmb.addSubBehaviour(new Estado2(a));
			return 0;
		}	
	}

	private class Estado3 extends OneShotBehaviour{
		private String receptorname;
		private Agent a;
		public Estado3(Agent a){
			this.a=a;
		}
		public void onStart(){
			receptorname = "receptor";
		}	
		public void action(){
			AID id = new AID();
			id.setLocalName(receptorname);
		
			ACLMessage mensaje = new ACLMessage(ACLMessage.REQUEST);

			mensaje.setSender(getAID());
			mensaje.setLanguage("Spanish");
			mensaje.addReceiver(id);
			mensaje.setContent("BIBA PROLOJ");

			send(mensaje);
		}
		public int onEnd(){
			System.out.println("3.FSMB");
			fsmb.addSubBehaviour(new Estado(a, 4));
			return 0;
		}

	}

	private class Estado2 extends Behaviour{

		private int i;
		private Agent a;

		public Estado2(Agent a){
			super(a);
			this.a = a;
		}
		public void onStart(){
			this.i = 0;
		}
		public void action(){
			System.out.print(this.i + " ");
			this.i++;
		}
		public boolean done(){
			return i > 20;
		}
		public int onEnd(){
			System.out.println("");
			System.out.println("2. FSMB");
			fsmb.addSubBehaviour(new Estado3(a));
			return 0;
		}
	}
}

