package examples;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.core.NotFoundException;
 
public class AgenteHebra extends Agent{
 
	private Behaviour comp, comp2, wakeup; 
	private ThreadedBehaviourFactory tbf;
	private int x; 

	protected void setup()
	{	
		x = 0;
		comp = new MiComportamiento(2000, "Comportamiento1");
		comp2 = new MiComportamiento(3000, "Comportamiento2");
		tbf = new ThreadedBehaviourFactory();
		addBehaviour(tbf.wrap(comp));
		addBehaviour(tbf.wrap(comp2));
		wakeup = new WakeUp(this, 12000);
		addBehaviour(wakeup);
	}
	protected void takeDown()
	{
		System.out.println("Taking down");
		
		try{
			Thread td1 = tbf.getThread(comp);
			tbf.interrupt(td1);
		}catch(InterruptedException e){
			Thread.currentThread().interrupt(); 
		}
		try{
			Thread td2 = tbf.getThread(comp2);
			tbf.interrupt(td2);
		}catch(InterruptedException e){
			Thread.currentThread().interrupt(); 
		}
		super.takeDown();
	} 
	public class WakeUp extends WakerBehaviour {
		private long t;
		public WakeUp(Agent a, long timeout){
			super(a,timeout);
			t=timeout;
		}
		protected void handleElapsedTimeout() {
			System.out.println("Time Out. Agente WakeUp");
			myAgent.doDelete();
		}
	}
	private class MiComportamiento extends CyclicBehaviour{ 

		private int n;
		private String name; 

		public MiComportamiento(int n, String name){
			this.n = n;
			this.name = name;
		}
	    	public void action(){
			try{
				Thread.sleep(this.n);
			}catch(InterruptedException e){
				System.out.println(e);
			}
		    	System.out.println(this.name + "-> : El valor de x es: " + x);
			if(this.name.equals("Comportamiento1")) x++;
			else x--;
		}
	}
}
