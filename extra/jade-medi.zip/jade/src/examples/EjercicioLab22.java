package examples;

import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.FSMBehaviour;
import jade.core.behaviours.Behaviour;


public class EjercicioLab22 extends Agent { //Puede ser cualquier tipo de comportamiento
	// State names
	private static final String STATE_0 = "INICIO";
	private static final String STATE_1 = "Q1";
	private static final String STATE_2 = "Q2";
	private static final String STATE_F = "FIN";

	protected void setup() {
		FSMBehaviour fsm = new FSMBehaviour(this) {
			public int onEnd() {
				System.out.println("FSM behaviour completed.");
				return 0;
			}
		};

		
		// Register state 0 (first state)
		fsm.registerFirstState(new NamePrinter(), STATE_0);
		
		// Register state 1
		fsm.registerState(new RandomGenerator(4), STATE_1);
		
		// Register state 2 	
		fsm.registerState(new MiComportamiento(2), STATE_2);
		
		// Register state F
		fsm.registerLastState(new NamePrinter(), STATE_F);


		// Register the transitions
		fsm.registerDefaultTransition(STATE_0, STATE_1);
		fsm.registerDefaultTransition(STATE_2, STATE_F);
		fsm.registerTransition(STATE_1, STATE_1, 0);
		fsm.registerTransition(STATE_1, STATE_1, 1);
		fsm.registerTransition(STATE_1, STATE_1, 2);
		fsm.registerTransition(STATE_1, STATE_2, 3);
		
		addBehaviour(fsm);
	}
	

	private class NamePrinter extends OneShotBehaviour {
		public void action() {
			System.out.println("Soy el estado nº : "+ getBehaviourName());
		}
	}

	private class RandomGenerator extends NamePrinter {
		private int maxExitValue;
		private int exitValue;
		
		private RandomGenerator(int max) {
			super();
			maxExitValue = max;
		}
		
		public void action() {
			System.out.println("Soy el estado nº : "+ getBehaviourName());
			exitValue = (int) (Math.random() * maxExitValue); 
			System.out.println("Exit value is "+exitValue);
		}
		
		public int onEnd() {
			return exitValue;
		}
	}
	private class MiComportamiento extends Behaviour{
	 	private int x;
		public MiComportamiento(int x){
			this.x = x;
		}
		// Función que realiza MiComportamiento
		public void action(){
		    	System.out.println("Soy el estado nº : "+ this.x);
		}
	 
		// Comprueba si el comportamiento ha finalizado.
		public boolean done(){
		    return true;
		}
    }
}
