package examples;

import jade.core.Agent;
import jade.core.behaviours.*;
 
public class MiAgente extends Agent{
 
    protected void setup(){
    //Aqui es donde se añade el comportamiento.
        addBehaviour(new MiComportamiento1());
        addBehaviour(new MiComportamiento2());

    }
    //Este es el comportamiento1.
    private class MiComportamiento1 extends Behaviour{
        public void action(){
        System.out.println("Mi nombre es: "+getName() );
            System.out.println("Soy el comportamiento1 del agente");
 
    	}
        public boolean done(){
	//Si indicamos en esta variable false, el metodo action() se repite de forma cíclica, acabando con un error porque solicita el metodo done().
            return true;
        }
    }

    //Este es el comportamiento2.
    private class MiComportamiento2 extends Behaviour{
        public void action(){
        System.out.println("Mi nombre es: "+getName() );
            System.out.println("Soy el comportamiento2 del agente");
 
    	}
        public boolean done(){
	//Si indicamos en esta variable false, el metodo action() se repite de forma cíclica, acabando con un error porque solicita el metodo done().
            return true;
        }
    }
}
