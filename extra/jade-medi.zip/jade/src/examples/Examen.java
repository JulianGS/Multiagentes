package examples;

import jade.core.Agent;
import jade.core.behaviours.*;


public class Examen extends Agent{
	private Behaviour l;
	private int temperatura;

	protected void setup(){
		temperatura = (int)(Math.random() * 8);
		temperatura = temperatura + 24;
		l = new Lectura();
		addBehaviour(l);		
	}
	protected void takeDown(){
		System.out.println("Liberando Recursos");
	}
	private class Lectura extends Behaviour{

		public void onStart(){
			System.out.println("Lectura Inicial: " + temperatura);
			block(2000);
		}		
		public void action(){
			block(2000);
			System.out.println("Comportamiento Lectura actual: " + temperatura);
			if(temperatura > 28) myAgent.addBehaviour(new Enfriar());
			else if(temperatura < 28) myAgent.addBehaviour(new Calentar());
		}
		public boolean done(){
			return (temperatura == 28);
		}
		public int onEnd(){
			System.out.println("Fin comportamiento Lectura, Lectura tomada: " + temperatura);
			System.out.println("Iniciando nueva lectura...");
			temperatura = (int)(Math.random() * 8);
			temperatura = temperatura + 24;
			l.reset();
			myAgent.addBehaviour(l);
			return 0;
		}
	}
	private class Calentar extends OneShotBehaviour{		
		public void action(){
			System.out.println("Comportamiento Calentar actual: " + temperatura);
			temperatura += 1;
		}
		public int onEnd(){
			return 0;
		}
	}
	private class Enfriar extends OneShotBehaviour{	
		public void action(){
			System.out.println("Comportamiento Enfriar actual: " + temperatura);
			temperatura -= 1;
		}
		public int onEnd(){
			return 0;
		}
	}
}
