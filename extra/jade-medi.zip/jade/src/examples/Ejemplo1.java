package examples;

import jade.core.Agent;
import jade.core.behaviours.*;
 
public class Ejemplo1 extends Agent{
 
    private Behaviour comp; //Variable tipo comportamiento
 
    // Inicialización del agente
    protected void setup()
    {
     //Creamos un comportamiento: un objeto de la clase MiComportamiento1
     comp = new MiComportamiento1();
     //Aqui es donde se añade el comportamiento.
     addBehaviour(comp);
    }
 
    //Definición de un comportamiento
    private class MiComportamiento1 extends Behaviour{ //Cuando heredo de comportamiento tengo que tener un action y done
 
    // define la acción a ser ejecutada cuando se ejecute el comportamiento.
    public void action(){
       System.out.println("Mi nombre es: "+getName() );
       System.out.println("Soy el primer comportamiento");
       // Añade un comportamiento desde otro comportamiento.
       myAgent.addBehaviour(new MiComportamiento2()); //No es necesario pero se puede poner
        }
 
        // Determina si el comportamiento ha sido completado o no.
        // Si el comportamiento ha finalizado, éste se elimina
      // de la cola de comportamientos activos.
        public boolean done(){
            return false; //Solo se ejecuta una vez
        }
    }
 
    //Definición de un segundo comportamiento
    private class MiComportamiento2 extends Behaviour{
        public void action(){
            System.out.println("Soy el segundo comportamiento");
            myAgent.removeBehaviour(comp); //comp hace referencia al primer comportamiento
	  //Borramos el primer comportamiento;
        }
        public boolean done(){
            return true; //se ejecuta tambien una sola vez
        }
    }
 
}
