package examples.comunicacion4;

import java.util.StringTokenizer;
import jade.core.Agent;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.AchieveREResponder;
import jade.domain.FIPANames;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.domain.FIPAAgentManagement.FailureException;
 
 
public class Taller extends Agent {
 
    public int CODIGO_AVERIA;
    Object[] args;
 
    protected void setup()
    {
        
        args = getArguments();
        if (args != null && args.length > 0 ) {
        
		CODIGO_AVERIA=(int)(Math.random()*40); //Pueden reparar desde 0 hasta este random
        	System.out.println("Taller "+getLocalName()+": Esperando avisos...");
        	MessageTemplate protocolo = MessageTemplate.MatchProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
        	MessageTemplate performativa = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
	        MessageTemplate plantilla = MessageTemplate.and(protocolo, performativa);
 
        	addBehaviour(new ManejadorResponder(this, plantilla));
    }

	else 

		System.out.println("Debe de indicar la marca de los vehículos a reparar en este taller.");

    }
 
    class ManejadorResponder extends AchieveREResponder
    {
        public ManejadorResponder(Agent a,MessageTemplate mt) {
            super(a,mt);
        }
 
        protected ACLMessage handleRequest(ACLMessage request)throws NotUnderstoodException, RefuseException
        {
      
            StringTokenizer st=new StringTokenizer(request.getContent());
            String contenido=st.nextToken();
		
            if(contenido.equalsIgnoreCase("SEAT")) 
            {
                st.nextToken();
                int CodAveria=Integer.parseInt(st.nextToken());
                if (CodAveria < 40)
                {

                    ACLMessage agree = request.createReply();
		    System.out.println("Taller "+getLocalName()+": Va a buscar la averia");
                    agree.setPerformative(ACLMessage.AGREE);
                    return agree;
                }
                else
                {
                   
                    throw new RefuseException("No somos capaces de reparar la averia");
                }
            }
            else throw new NotUnderstodException
("los mecánicos no entienden de esta marca de vehículos.");
        }
 
        protected ACLMessage prepareResultNotification(ACLMessage request,ACLMessage response) throws FailureException
        {
            if (Math.random() > 0.1) {
                
                ACLMessage inform = request.createReply();
		System.out.println("Taller " +getLocalName()+" ha terminado de atender la averia");		
                inform.setPerformative(ACLMessage.INFORM);
                return inform;
            }
            else
            {
                throw new FailureException("dirección desconocida no se ha podido recoger el vehículo.");
            }
        }
    }
}
