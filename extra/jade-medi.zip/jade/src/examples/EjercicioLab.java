package examples;

import jade.core.Agent;
import jade.core.behaviours.*;
 
public class EjercicioLab extends Agent{
 
    private Behaviour comp; 
 
    protected void setup()
    {
     comp = new MiComportamiento1();
     addBehaviour(comp);
    }
    protected void takeDown()
    {
        System.out.println("****Liberando Recursos****");
    } 
    //Definición de un comportamiento
    private class MiComportamiento1 extends Behaviour{ 
	
	private int x;

	public void onStart(){
           this.x = 0;
	   System.out.println("Mi nombre es: "+getName() );
    	   System.out.println("Soy el primer comportamiento");
	}
    	public void action(){
	   if(x==5){
                this.block();
	        addBehaviour(new MiComportamiento2());
	   }
    	   System.out.println(getName() + " (1) : El valor de x es: " + x);
	   this.x++;
        }
    	public boolean done(){
	    if(this.x == 8){
                myAgent.doDelete();
		return true;
	    }else return false;
        }
        public int onEnd(){
            
            return 0;
        }
    }
    private class MiComportamiento2 extends Behaviour{

	private int y = 5;
 
    	public void onStart(){
	   System.out.println("Mi nombre es: " + getName() );
    	   System.out.println("Soy el segundo comportamiento");
	}
    	public void action(){
    	   System.out.println(getName() + " (2) : El valor de y es: " + y);
	    this.y--;
        }
    	public boolean done(){
	    return(this.y==0);
        }
        public int onEnd(){
            comp.restart();
            return 0;
        }
    } 
}
