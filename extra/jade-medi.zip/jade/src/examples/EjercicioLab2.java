package examples;

import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.ParallelBehaviour;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.SimpleBehaviour;
import jade.core.behaviours.WakerBehaviour;
import java.util.Date;

public class EjercicioLab2 extends Agent {
	private static final long serialVersionUID = 1L;
	
	protected void setup() {
		ParallelBehaviour pb = new ParallelBehaviour(this,3)
			{
				public int onEnd(){
					System.out.println("Fin agente");
					return 0;
				}
			};
		pb.addSubBehaviour(new MiComportamiento1());
		pb.addSubBehaviour(new MiComportamiento2());
		Date d = new Date();
		d.setSeconds(d.getSeconds() + 5);
		pb.addSubBehaviour(new MiComportamiento3(this, d));	
		addBehaviour(pb);		
	}
	private class MiComportamiento1 extends Behaviour{
		private int x;

		public void onStart(){
			this.x = 0;
		}
		public void action(){
			this.x++;
			System.out.println("Soy el primer subcomportamiento y estoy en la " + x + " ejecucion");
		}
		public boolean done(){
			return this.x > 2;
		}			
	}
	private class MiComportamiento2 extends OneShotBehaviour{
		public void action(){
			System.out.println("Soy el segundo subcomportamiento");
		}			
	}
	private class MiComportamiento3 extends WakerBehaviour{
		private static final long serialVersionUID = 1L;

		public MiComportamiento3(Agent a, Date wakeupDate) {
			super(a, wakeupDate);
		}
		
		protected void onWake() {
			System.out.println("Soy el tercer subcomportamiento y acabo de despertar");
		}
	}

	
}
