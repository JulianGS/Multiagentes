package examencomunicacion;

import jade.core.Agent;
import jade.core.behaviours.*;
import java.util.ArrayList;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.core.AID;

public class Receptor extends Agent{
	private Behaviour par1, impar1, par2, impar2;
	private ParallelBehaviour pb;	
	
	protected void setup(){
		System.out.println("Iniciando Agente Receptor...");
		pb = new ParallelBehaviour(this, ParallelBehaviour.WHEN_ANY){
			public int onEnd(){
				reset();
				myAgent.doDelete();
				return super.onEnd();
			}
		};
		par1 = new Lector(0);
		impar1 = new Lector(1);
		par2 = new Lector(2);
		impar2 = new Lector(3);

		pb.addSubBehaviour(par1);
		pb.addSubBehaviour(impar1);
		pb.addSubBehaviour(par2);
		pb.addSubBehaviour(impar2);

		addBehaviour(pb);
		
	}
	protected void takeDown(){
		System.out.println("Liberando recursos Agente Receptor...");
		super.takeDown();
	}
	private class Lector extends Behaviour{
		private int id;
		private ArrayList<Integer> cola;
		MessageTemplate plantilla = null;
		private int acum;
		public Lector(int id){
			this.acum = 0;
			this.id = id;
			this.cola = new ArrayList<Integer>();

			AID emisor = new AID();
			if(id == 0 || id == 1){
				emisor.setLocalName("e1");
			}else{
				emisor.setLocalName("e2");
			}
			MessageTemplate filtroEmisor = MessageTemplate.MatchSender(emisor);
			MessageTemplate filtroInform = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
			MessageTemplate filtroIdioma;
			if(id == 0 || id == 2){
				 filtroIdioma = MessageTemplate.MatchLanguage("par");
			}else{
				 filtroIdioma = MessageTemplate.MatchLanguage("impar");
			}

			plantilla = MessageTemplate.and(filtroInform,filtroEmisor);
			plantilla = MessageTemplate.and(plantilla,filtroIdioma);
		}
		public void onStart(){
			if(this.id == 0 || this.id == 1) System.out.println(this.id + " --- Solo recibo cosas del emisor 1");
			else System.out.println("Yo no recibo nada");
		}
		public void action(){
			ACLMessage mensaje = blockingReceive(plantilla);
			System.out.println(" -- " + this.id + " - " + mensaje.toString());
			String n = mensaje.getContent();
			int num = n.Integer.parseInt();
			if(num > 60) this.acum++;
			cola.add(num);
		}
		public boolean done(){
			return acum > 3;
		}
		public int onEnd(){
			return 0;
		}
	}
}
