package examencomunicacion;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import jade.core.AID;

public class Emisor2 extends Agent{
	protected void setup(){
		System.out.println("Iniciando Agente Emisor1...");
		addBehaviour(new Emisor());
	}
	protected void takeDown(){
		System.out.println("Liberando recursos Agente Emisor1...");
		super.takeDown();
	}
	private class Emisor extends CyclicBehaviour{
		private int n;
		public void onStart(){

		}
		public void action(){
			n = ((int)(Math.random()*50));
			n = n + 50;
			block(500);

		        AID id = new AID();
		        id.setLocalName("r");
	 
		        ACLMessage mensaje = new ACLMessage(ACLMessage.REQUEST);
		        mensaje.setSender(getAID());
			if(n%2 == 0) mensaje.setLanguage("par");
			else  mensaje.setLanguage("impar");
		        mensaje.addReceiver(id);
		        mensaje.setContent("" + n);
	 
		        send(mensaje);
 
		}
	}
}
